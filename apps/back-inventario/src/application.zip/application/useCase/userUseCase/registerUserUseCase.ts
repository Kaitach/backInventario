/* eslint-disable prettier/prettier */
import { Injectable } from "@nestjs/common";
import { UserDomainService, IUserEntity } from "apps/back-inventario/src/domain";
import { Observable } from "rxjs";

@Injectable()
export class registeruserUseCase {
  constructor(private readonly userService: UserDomainService<IUserEntity>) { }

  registeruser(data: IUserEntity): Observable<IUserEntity> {
    return this.userService.registerUser(data);
  }

  execute(data: IUserEntity): Observable<IUserEntity> {
    return this.registeruser(data);
  }
}
