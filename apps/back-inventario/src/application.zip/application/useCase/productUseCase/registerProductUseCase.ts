/* eslint-disable prettier/prettier */
import { Injectable } from "@nestjs/common";
import { IProductEntity } from "apps/back-inventario/src/domain";
import { Observable } from "rxjs";
import { ProductDomainService } from './../../../domain/services/productServiceDomain';

@Injectable()
export class registerProductUseCase {
  constructor(private readonly productDomainService: ProductDomainService<IProductEntity>) { }

  registerProduct(data: IProductEntity): Observable<IProductEntity> {
    return this.productDomainService.registerProduct(data);
  }

  execute(data: IProductEntity): Observable<IProductEntity> {
    return this.registerProduct(data);
  }
}
