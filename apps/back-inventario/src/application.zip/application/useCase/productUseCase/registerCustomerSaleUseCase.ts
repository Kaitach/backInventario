/* eslint-disable prettier/prettier */
import { Injectable } from "@nestjs/common";
import { IProductEntity } from "apps/back-inventario/src/domain";
import { Observable } from "rxjs";
import { ProductDomainService } from './../../../domain/services/productServiceDomain';

@Injectable()
export class registerCustomerSaleUseCase {
  constructor(private readonly productDomainService: ProductDomainService<IProductEntity>) { }

  registerCustomerSale(data: IProductEntity): Observable<IProductEntity> {
    return this.productDomainService.registerCustomerSale(data);
  }

  execute(data: IProductEntity): Observable<IProductEntity> {
    return this.registerCustomerSale(data);
  }
}
