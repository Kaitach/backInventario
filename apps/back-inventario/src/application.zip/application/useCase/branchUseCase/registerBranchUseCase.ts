/* eslint-disable prettier/prettier */
import { Injectable } from "@nestjs/common";
import { BranchDomainService, IBranch } from "apps/back-inventario/src/domain";
import { Observable } from "rxjs";

@Injectable()
export class registerBranchUseCase {
  constructor(private readonly branchService: BranchDomainService<IBranch>) { }

  registerBranch(data: IBranch): Observable<IBranch> {
    return this.branchService.RegisterBranch(data);
  }

  execute(data: IBranch): Observable<IBranch> {
    return this.registerBranch(data);
  }
}
