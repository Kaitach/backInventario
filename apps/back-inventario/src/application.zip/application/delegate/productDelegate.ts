/* eslint-disable prettier/prettier */
import { Injectable } from "@nestjs/common";
import { Observable } from "rxjs";
import { registerProductInventoryStockUseCase } from './../useCase/productUseCase/registerProductInventotyStockUseCase';

import { IProductEntity, ProductDomainService } from "../../domain";
import { registerCustomerSaleUseCase } from "../useCase/productUseCase/registerCustomerSaleUseCase";
import { registerProductUseCase } from "../useCase/productUseCase/registerProductUseCase";
import { registerResellerSaleUseCase } from '../useCase/productUseCase/registerResellerSaleUseCase';
import { IUseCase } from '../../domain/interfaces/IUseCase';


@Injectable()
export class productDelegate implements IUseCase {
  private delegate: IUseCase;

  constructor(
    private readonly productService: ProductDomainService<IProductEntity>
  ) { }

  execute<Response>(...args: any[]): Observable<Response> {
    return this.delegate.execute(...args);
  }

  registerCustomerSale(): void {
    this.delegate = new registerCustomerSaleUseCase(
      this.productService
    );
  }

  registerProduct(): void {
    this.delegate = new registerProductUseCase(
      this.productService
    );
  }
  
  registerProductInventoryStock(): void {
    this.delegate = new registerProductInventoryStockUseCase(
      this.productService
    );
  }
  
  registerResellerSale(): void {
    this.delegate = new registerResellerSaleUseCase(
      this.productService
    );
  }
}
